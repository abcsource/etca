#include "types.h"
#include "user.h"
#include "stat.h"
#include "fcntl.h"
enum procstate { UNUSED, EMBRYO, SLEEPING, RUNNABLE, RUNNING, ZOMBIE };
char *str[] =  { "UNUSED", "EMBRYO", "SLEEPING", "RUNNABLE", "RUNNING", "ZOMBIE" };
int 
main(int argc, char ** argv)
{
	if(argc!=2)
	{
		printf(1,"Error\n");
		exit();
	}
	int n = atoi(argv[1]);
	struct ProcessInfo pi;
	cps(n,&pi);
	printf(1,"%d %s %s\n",pi.pid,pi.name,str[pi.state]);
	exit();
}