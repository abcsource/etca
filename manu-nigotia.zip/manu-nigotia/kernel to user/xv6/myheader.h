
struct ProcessInfo
{
	int pid;
	char name[16];
	int state;
};

