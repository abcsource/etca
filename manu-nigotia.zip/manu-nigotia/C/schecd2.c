#include <stdio.h>
#include<stdlib.h>

struct PROC
{
	int pid,priority,bt,wt,tat,st;
};

typedef struct PROC proc;


void fcfs(proc arr[])
{
	printf("fcfs\n");
	int currTime = 0;
	for(int i=0;i<4;i++)
	{
		arr[i].wt = currTime - arr[i].st;
		currTime += arr[i].bt;
		arr[i].tat = currTime - arr[i].st;
	}

	for(int i=0;i<4;i++)
	{
		printf("%d WT : %d , TAT : %d\n",arr[i].pid,arr[i].wt,arr[i].tat);
	}
}

int cmp(const void * a, const void * b)
{
	return (*(proc * ) a).bt - (*(proc * ) b).bt;
}

int cmp_p(const void * a, const void * b)
{
	return (*(proc * ) b).priority - (*(proc * ) a).priority;
}

int priority(proc * arr)
{
	printf("Priority\n");
	int currTime = 0;
	qsort(arr,4,sizeof(proc),cmp_p);
	for(int i=0;i<4;i++)
	{
		arr[i].wt = currTime - arr[i].st;
		currTime += arr[i].bt;
		arr[i].tat = currTime - arr[i].st;
	}

	for(int i=0;i<4;i++)
	{
		printf("%d WT : %d , TAT : %d\n",arr[i].pid,arr[i].wt,arr[i].tat);
	}
}

void sjf(proc * arr)
{
	printf("SJF\n");
	int currTime = 0;
	qsort(arr,4,sizeof(proc),cmp);
	for(int i=0;i<4;i++)
	{
		arr[i].wt = currTime - arr[i].st;
		currTime += arr[i].bt;
		arr[i].tat = currTime - arr[i].st;
	}

	for(int i=0;i<4;i++)
	{
		printf("%d WT : %d , TAT : %d\n",arr[i].pid,arr[i].wt,arr[i].tat);
	}
}
void rr(proc * arr)
{
	printf("RR\n");
	int j = 0;
	int currTime = 0;
	int lt[4]={0};
	while(1)
	{
		int f = 0,last = j;
		for(int i=0;i<4;i++)
			if(arr[i].bt!=0)
			{
				f=1;
				break;
			}
		if(!f)
			break;
		while(arr[j].bt==0)
			j = (j+1)%4;
		
		arr[j].wt += currTime - lt[j];
		for(int i=0;i<2;i++)
		{
			arr[j].bt--;
			currTime++;
			//printf("Executing %d\n",j+1);
			//sleep(1);
			if(arr[j].bt==0)
				break;
		}
		lt[j] = currTime;
		j= (j+1)%4;
	}
	for(int i=0;i<4;i++)
	{
		printf("%d WT : %d , TAT : %d\n",arr[i].pid,arr[i].wt,lt[i]-arr[i].st);
	}
}
int main()
{
	proc arr[4] = {
		{1,2,24,0,0,0},
		{2,4,3,0,0,0},
		{3,3,3,0,0,0},
		{4,1,7,0,0,0}
	};
	proc arr1[4] = {
		{1,2,24,0,0,0},
		{2,4,3,0,0,0},
		{3,3,3,0,0,0},
		{4,1,7,0,0,0}
	};
	for(int i=0;i<4;i++)
	{
		printf("%d %d %d\n",arr[i].pid,arr[i].priority,arr[i].bt);
	}
	rr(arr1);
	fcfs(arr);
	sjf(arr);
	priority(arr);
}