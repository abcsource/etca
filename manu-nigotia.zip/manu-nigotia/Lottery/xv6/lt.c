#include "types.h"
#include "user.h"
#include "stat.h"
#include "fcntl.h"


int main(int argc,char ** argv)
{
	if(argc!=3)
	{
		printf(1,"Invalid arguments\n");
		exit();
	}

	chlt(atoi(argv[1]),atoi(argv[2]));
	exit();
}