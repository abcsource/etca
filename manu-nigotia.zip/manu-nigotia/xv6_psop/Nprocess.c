#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int 
main(int argc, const char ** argv)
{
	if(argc < 2)
	{
		printf(1,"Invalid number of arguments\n");
		exit();
	}
	int n = atoi(argv[1]),i;
	if(n<0 || n > 20)
		n = 1;
	int p=0;
	for(i=0;i<n;i++)
	{
		if(p==0) p = fork();
	}
	if(p!=0)
	{
		wait();
		printf(1, "parent exitting\n",getpid());
		exit();
	}
	sleep(10000);
	printf(1,"%d exitting\n",getpid());
	exit();
}


