#include "types.h"
#include "stat.h"
#include "fcntl.h"
#include "user.h"

int 
main(int argc,const char ** argv)
{
	chpr(atoi(argv[1]),atoi(argv[2]));
	exit();
}
