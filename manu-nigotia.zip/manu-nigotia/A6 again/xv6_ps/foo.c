#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc , const char ** argv)
{
	int n,i;
	if(argc < 2) n = 1;
	else n = atoi(argv[1]);
	
	if(n<0 || n> 20)
		n = 2;
		//i=20;
	double x= 0,z;
	printf(1,"%d\n",n);
	int pid = 0;
	for(i=0;i<n;i++)
	{
		pid = fork();
		
		if(pid == -1)
		{
			printf(1,"%d failed in fork\n",getpid());
		}
		else if(pid>0)
		{
			printf(1,"Parent %d Creating child with pid %d\n",getpid(),pid);
			//wait();
		}
		
		else
		{
			printf(1,"CHild with pid %d created\n",getpid());
			for(z=0;z<8000000.0;x+=0.01)
				x = x + 3.14 * 89.89;
			break;
		}
	}
	if(pid>0)
	wait();
	exit();
}

